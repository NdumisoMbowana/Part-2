using Part2;

namespace TotalCalorie
{
    
    public class UnitTest1
    {
   
      
        public void TotalCalories_CalculatesCorrectly()
        {
            // Arrange
            Recipe recipe = new Recipe("Test Recipe");
            List<Ingredient> ingredients = new List<Ingredient>
        {
            new Ingredient { Name = "Ingredient 1", Quantity = 100, Unit = "g", Calories = 50, FoodGroup = "Group A" },
            new Ingredient { Name = "Ingredient 2", Quantity = 200, Unit = "g", Calories = 70, FoodGroup = "Group B" },
            new Ingredient { Name = "Ingredient 3", Quantity = 150, Unit = "g", Calories = 80, FoodGroup = "Group C" }
        };
            foreach (var ingredient in ingredients)
            {
                recipe.AddIngredient(ingredient.Name, ingredient.Quantity, ingredient.Unit, ingredient.Calories, ingredient.FoodGroup);
            }

          
            int totalCalories = recipe.TotalCalories();

           
            Assert.AreEqual(200, totalCalories, "Total calories should be calculated by summing the calories of all ingredients in the recipe");
        }
    }

}
