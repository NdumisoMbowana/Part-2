﻿using Part2;

public class Program
{
    static List<Recipe> recipes = new List<Recipe>();
    static event RecipeCaloriesNotification NotifyCaloriesExceed;

    static void Main(string[] args)
    {
        NotifyCaloriesExceed += NotifyCaloriesExceedHandler;

        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Enter a new recipe");
            Console.WriteLine("2. Display all recipes");
            Console.WriteLine("3. Display a recipe");
            Console.WriteLine("4. Exit");
            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    EnterNewRecipe();
                    break;
                case 2:
                    DisplayAllRecipes();
                    break;
                case 3:
                    DisplayRecipe();
                    break;
                case 4:
                    exit = true;
                    Console.WriteLine("Thank you for using the app. Goodbye.");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    static void EnterNewRecipe()
    {
        Console.Write("Enter the name of the recipe: ");
        string name = Console.ReadLine();
        Recipe recipe = new Recipe(name);

        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"Enter the Ingredient {i + 1}:");
            Console.Write("Name: ");
            string ingredientName = Console.ReadLine();

            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());

            Console.Write("Unit of measurement: ");
            string unit = Console.ReadLine();

            Console.Write("Calories: ");
            int calories = int.Parse(Console.ReadLine());

            Console.Write("Food group: ");
            string foodGroup = Console.ReadLine();

            recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"Enter Step {i + 1}:");
            Console.Write("Description: ");
            string description = Console.ReadLine();
            recipe.AddStep(description);
        }

        recipes.Add(recipe);

        int totalCalories = recipe.TotalCalories();
        if (totalCalories > 300)
        {
            NotifyCaloriesExceed(name, totalCalories);
        }
    }

    static void DisplayAllRecipes()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes entered yet.");
            return;
        }

        Console.WriteLine("List of Recipes:");
        foreach (var recipe in recipes.OrderBy(r => r.Name))
        {
            Console.WriteLine(recipe.Name);
        }
    }

    static void DisplayRecipe()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes entered yet.");
            return;
        }

        Console.WriteLine("Choose a recipe to display:");
        for (int i = 0; i < recipes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {recipes[i].Name}");
        }

        Console.Write("Enter the number of the recipe: ");
        int recipeIndex = int.Parse(Console.ReadLine()) - 1;

        if (recipeIndex >= 0 && recipeIndex < recipes.Count)
        {
            recipes[recipeIndex].DisplayRecipe();
        }
        else
        {
            Console.WriteLine("Invalid recipe number.");
        }
    }

    static void NotifyCaloriesExceedHandler(string recipeName, int totalCalories)
    {
        Console.WriteLine($"Warning: The total calories of recipe '{recipeName}' exceed 300. Total calories: {totalCalories}");
    }
}

